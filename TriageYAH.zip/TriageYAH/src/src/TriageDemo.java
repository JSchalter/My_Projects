package src;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TriageDemo {

    public static void main(String[] args) throws FileNotFoundException {

        File file = new File("TriageList");
        if (!file.exists()) {
            //System.out.println("The TriageList file is not found.");
            System.exit(0);
        }

        src.TriageSimulator triSim = new src.TriageSimulator();

        System.out.println("\n*** Initializing... ***\n");
        System.out.println("The contents of the file include: \n");

        Scanner scan = new Scanner(file);
//String priority; //don't think I need

        while (scan.hasNext())
        {
            String x = scan.nextLine();
            System.out.println(x);
            triSim.add(x);

        } //end while

        System.out.println("\n*** File-reading complete. ***\n");

        System.out.println("\nHospital Priority Queue:\n");

        while (!triSim.isEmpty())
        {
            System.out.println(triSim.remove());
        }

        scan.close();

    } // end main

} // end TriageDemo